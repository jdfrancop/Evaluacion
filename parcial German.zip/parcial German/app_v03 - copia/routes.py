from controllers import *

routes = {
"register": "/registeruser", "register_controllers": RegisterControllers.as_view("register_api"),
"login": "/login", "login_controllers": LoginControllers.as_view("login_api"),
"nuevo": "/nuevo", "nuevo_controllers": NuevoControllers.as_view("nuevo_api"),
"productos": "/productos", "productos_controllers": ProductosControllers.as_view("productos_api")
}
