from flask.views import MethodView
from flask import jsonify, request
from model import users
import bcrypt
import jwt
from config import KEY_TOKEN_AUTH
import datetime
from validators import *
import pymysql

registro_schema= registerValidator()
nuevo_schema= nuevoValidator()
login_schema= loginValidator()

class RegisterControllers(MethodView):
    """
        
    """

    def post(self):
        content = request.get_json()
        email = content.get("email")
        nombres = content.get("nombres")
        apellidos = content.get("apellidos")
        password = content.get("password")
    

        salt = bcrypt.gensalt()
        hash_password = bcrypt.hashpw(bytes(str(password), encoding= 'utf-8'), salt)

        errors = registro_schema.validate(content)

        if errors:
            return errors, 400

        conn = pymysql.connect(
        host="localhost", port=3306, user="root",
        passwd="Sena1234", db="productos"
        )
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO usuario(correo, nombres, apellidos, password) VALUES(%s, %s, %s, %s)",
             (email,nombres,apellidos,bytes.decode(hash_password, encoding='utf-8'))
        )

        conn.commit()
        conn.close()

      

        users[email] = {"password": hash_password, "nombres":nombres, "apellidos":apellidos}
        return jsonify({"Status": "Registro ok",
                    "password_encriptado": hash_password.decode(),
                    "password_plano": password}), 200



class LoginControllers(MethodView):
    
        
    def post(self):
        content = request.get_json()
        password =  bytes(str(content.get("password")), encoding= 'utf-8')
        email = content.get("email")

        errors = login_schema.validate(content)

        if errors:
            return errors, 400
        
        conn = pymysql.connect(
        host="localhost", port=3306, user="root",
        passwd="Sena1234", db="productos"
        )
        cursor = conn.cursor()
        cursor.execute(
            f"SELECT correo, password FROM usuario WHERE correo='{email}'"
        )
        data = cursor.fetchone()
       
        conn.commit()
        conn.close()
        if data:
            if bcrypt.checkpw(password,bytes(data[1], encoding='utf-8')):
                encoded_jwt = jwt.encode({'exp': datetime.datetime.utcnow() + datetime.timedelta(seconds=300), 'correo': email}, KEY_TOKEN_AUTH , algorithm='HS256')
                return jsonify({"Status": "Login OK", "token": encoded_jwt}), 200

            return jsonify({"Status": "Login Fail, contraseña incorrecta"}), 402
        return jsonify({"Status": "Login Fail, usuario no registrado"}), 402



class NuevoControllers(MethodView):
    """
        Example Json
    """
    def post(self):
        content = request.get_json()
        print(content)
        nombre = content.get("nombre")
        precio = content.get("precio")
       
        errors = nuevo_schema.validate(content)

        if errors:
            return errors, 400


        conn = pymysql.connect(
        host="localhost", port=3306, user="root",
        passwd="Sena1234", db="productos"
        )
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO produtos(nombre, precio) VALUES(%s, %s)",
             (nombre, precio)
        )

        conn.commit()
        conn.close()


        
        if (request.headers.get('Authorization')):
            token = request.headers.get('Authorization').split(" ")
            print("-----------------_", token[1])
            try:
                data = jwt.decode(token[1], KEY_TOKEN_AUTH , algorithms=['HS256'])
                
                return jsonify({"Status": "Producto Creado con exito OK"}), 200
            except:
                return jsonify({"Status": "TOKEN NO VALIDO"}), 403
        return jsonify({"Status": "No ha enviado un token"}), 403
        
        
        
        #return jsonify({"Status": "Compra OK","idproducto": idproducto}), 200


class ProductosControllers(MethodView):
    """
        Example verify Token
    """
    def get(self):

        conn = pymysql.connect(
        host="localhost", port=3306, user="root",
        passwd="Sena1234", db="productos"
        )
        cursor = conn.cursor()
        cursor.execute(
            f"SELECT * FROM produtos "
        )
        data = cursor.fetchall()
        conn.commit()
        conn.close()
        productos = {}
        for producto in data:
            productos[producto[0]] = {
                "Producto": producto[1],
                "Valor": producto[2]
            }
        return jsonify({"Productos": productos}), 200
        # return jsonify({"Productos": data}), 200