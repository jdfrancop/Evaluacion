from marshmallow import Schema, fields, validate

class registerValidator(Schema):

    #def verificar_ciudad(x):
        #return True if not x.isspace() else False

    email = fields.Str(required=True, validate=validate.Email())
    nombres = fields.Str(required=True, validate=validate.Length(min=1, max=200))
    apellidos = fields.Str(required=True, validate=validate.Length(min=1, max=200))
    password = fields.Str(required=True, validate=validate.Length(min=8, max=12))


class nuevoValidator(Schema):

        
    nombre = fields.Str(required=True, validate=validate.Length(min=1, max=200))
    precio = fields.Int(required=True, validate=validate.Range(min=0, max=1000000))
    

class loginValidator(Schema):

    email = fields.Str(required=True, validate=validate.Email())
    password = fields.Str(required=True, validate=validate.Length(min=8, max=12))

    

